<?php

namespace Xanax\Exception;

use Exception;

class StupidIdeaException extends Exception
{
}
