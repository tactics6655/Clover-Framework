<?php

namespace Xanax\Interpreter;

class Parser
{
}
