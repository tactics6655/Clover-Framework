<?php

namespace Xanax\Enumeration;

abstract class CharacterSet
{
    const UTF_8 = 'UTF-8';
}
