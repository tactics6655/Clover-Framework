<?php

class Scalar
{
}
