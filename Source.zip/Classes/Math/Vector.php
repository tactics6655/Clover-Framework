<?php

class Vector
{
}
