<?php

class File
{
}
