<?php

class SimpleCrypto
{
}
