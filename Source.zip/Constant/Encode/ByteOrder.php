<?php

define(__UTF_8__, "utf-8");
define(__UTF_16_BIG_ENDIAN__, "utf-16 big endian");
define(__UTF_16_LITTLE_ENDIAN__, "utf-16 little endian");
define(__UTF_32_BIG_ENDIAN__, "utf-32 big endian");
define(__UTF_32_LITTLE_ENDIAN__, "utf-32 little endian");
