<?php

namespace Xanax\Classes;

class IterableFileHandler
{
}
