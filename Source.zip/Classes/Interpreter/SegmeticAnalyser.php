<?php

namespace Xanax\Interpreter;

class SegmeticAnalyser
{
}
