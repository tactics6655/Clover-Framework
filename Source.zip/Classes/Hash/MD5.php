<?php

namespace Xanax\Classes\Hash;

class MD5
{
}
