<?php

declare(strict_types=1);

namespace Xanax\Classes\Exception;

class Handler
{

	public static function setError(callable $callback)
	{
		$previous = self::setErrorHandler(function ($errorRaised, $errorMessage, $fileName, $lineNumber, $context) use (&$previous, $callback) {
			if ($previous && is_callable($callback)) {
				$callback($errorRaised, $errorMessage, $fileName, $lineNumber, $context);
			} else {
				return false;
			}
		});
	}

	public static function setErrorHandler($callback, $error_level = E_ALL)
	{
		return set_error_handler($callback, $error_level);
	}

	public static function registerShutdownFunction($callback, ...$args)
	{
		register_shutdown_function($callback, ...$args);
	}

	public static function clearLastError(): Void
	{
		error_clear_last();
	}

	public static function getLastError(): array
	{
		return error_get_last();
	}

	public static function setExceptionHandler(callable $exceptionFunction)
	{
		set_exception_handler($exceptionFunction);
	}

	public static function restorePreviousErrorStack()
	{
		restore_error_handler();
	}

	public static function restorePreviousExceptionStack()
	{
		restore_exception_handler();
	}

	public static function trigger($errorMessage)
	{
		trigger_error($errorMessage);
	}
}
