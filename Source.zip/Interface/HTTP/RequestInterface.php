<?php

namespace Xanax\Implement;

interface RequestInterface
{
}
