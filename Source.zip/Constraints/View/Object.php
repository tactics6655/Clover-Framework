<?php

class ViewObject
{
}
