<?php

declare(strict_types=1);

namespace Xanax\Classes\Event;

class Instance
{
}
