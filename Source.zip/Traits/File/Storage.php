<?php

namespace Xanax\Trait\File;

trait Storage
{
}
