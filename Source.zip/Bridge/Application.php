<?php

class Application
{
}
