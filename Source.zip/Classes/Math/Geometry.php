<?php

class Geometry
{
}
