<?php

namespace Xanax\Enumeration;

abstract class FileSizeUnit
{
    const SHORT = 'short';

    const LONG = 'long';
}
