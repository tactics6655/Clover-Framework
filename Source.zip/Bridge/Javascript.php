<?php

class Javascript
{
}
