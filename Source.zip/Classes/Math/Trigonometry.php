<?php

class Trigonometry
{
}
