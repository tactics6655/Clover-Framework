<?php

namespace Xanax\Traits\Regex;

trait Result
{
}
