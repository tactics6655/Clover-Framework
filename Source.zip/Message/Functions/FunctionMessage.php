<?php

namespace Xanax\Message\Functions;

class FunctionMessage
{

	public static function getFunctionIsNotFileMessage()
	{
		return 'Function is not exists';
	}
}
