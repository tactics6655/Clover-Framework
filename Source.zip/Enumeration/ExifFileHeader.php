<?php

namespace Xanax\Enumeration;

abstract class ExifFileHeader
{
    const MAIN_IMAGE = '1FD0';

    const THUMBNAIL_IMAGE = '1FD1';
}
