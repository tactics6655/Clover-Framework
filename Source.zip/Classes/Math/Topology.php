<?php

class Topology
{
}
