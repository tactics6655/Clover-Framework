<?php

namespace Xanax\Classes;

class Iterator
{
}
